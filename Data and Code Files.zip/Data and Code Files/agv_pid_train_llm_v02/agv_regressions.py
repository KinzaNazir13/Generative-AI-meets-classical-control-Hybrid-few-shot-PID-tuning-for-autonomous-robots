########################################################################################
# Title: AGV Regression Library
# Version: 1.1
# Date: 2025-03-12
# Description: This script is used to define regression libraies for AGV PID prediction.
########################################################################################
import os
import pandas as pd
import numpy as np
from joblib import load, dump
from sklearn.linear_model import LinearRegression, Ridge, Lasso
from sklearn.neighbors import KNeighborsRegressor
from sklearn.ensemble import RandomForestRegressor, VotingRegressor
from sklearn.model_selection import cross_val_score, GridSearchCV
from sklearn.preprocessing import PolynomialFeatures, StandardScaler, FunctionTransformer
from sklearn.compose import ColumnTransformer
from sklearn.linear_model import LinearRegression
from sklearn.pipeline import make_pipeline
from sklearn.svm import SVR
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.linear_model import HuberRegressor

import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import shap


# ---- Fine-Tuning Utilities ----
def fine_tune_ensemble(x_train, y_train,
                       load_path="ensemble_model.joblib",
                       save_path=None):
    """
    Load a pre-trained ensemble from load_path, warm-start and refit on new data,
    then dump to save_path (or a new file if save_path is None).
    """
    ensemble = load(load_path)

    # enable warm_start where supported
    if hasattr(ensemble, 'named_estimators_'):
        for est in ensemble.named_estimators_.values():
            if hasattr(est, 'warm_start'):
                est.set_params(warm_start=True)
                print(f">> warm_start enabled for {est.__class__.__name__}")

    # ????
    ensemble.fit(x_train, y_train)

    # if no save_path given, append "_finetuned" before extension
    if save_path is None:
        base, ext = os.path.splitext(load_path)
        save_path = f"{base}_finetuned{ext}"

    dump(ensemble, save_path)
    print(f">> fine-tuned and saved to {save_path}")

    return ensemble


def plot_heatmap(x_range, y_range, z_grid):
    # Plot as 2D heatmap
    plt.figure(figsize=(10, 8))
    plt.imshow(z_grid, cmap='viridis', origin='lower',
                extent=[x_range.min(), x_range.max(), y_range.min(), y_range.max()],
                aspect='auto')
    plt.colorbar(label='Predicted Value')
    plt.title('Heatmap of Regression Output')
    plt.xlabel('P')
    plt.ylabel('I')

    # # Annotate min and max points
    # plt.scatter([min_x], [min_y], color='red', label=f'Min: {min_value}', marker='o')
    # plt.scatter([max_x], [max_y], color='blue', label=f'Max: {max_value}', marker='x')
    # plt.scatter([min_x_2nd], [min_y_2nd], color='orange', label=f'2nd Min: {min_value_2nd}', marker='s')

    plt.legend()
    plt.tight_layout()
    plt.show()
        
def plot_3d_data(x_range, y_range, z_grid, points=None):
    # Extract data for visualization
    X, Y = np.meshgrid(x_range, y_range)
    Z = z_grid  # Interpolated values

    # Create a 3D plot
    fig = plt.figure(figsize=(10, 7))
    ax = fig.add_subplot(111, projection='3d')

    # Plot the surface
    surf = ax.plot_surface(X, Y, Z, cmap='viridis', edgecolor='k')

    # Set labels
    ax.set_xlabel('P-axis')
    ax.set_ylabel('I-axis')
    ax.set_zlabel('Predicted Values')
    ax.set_title('3D Visualization of Regression Output')

    # Add color bar
    fig.colorbar(surf, ax=ax, shrink=0.5, aspect=5)

    # Mark point2 if provided
    if points is not None:
        for point in points:
            ax.scatter(point[0], point[1], point[2], color='blue', label=f'Point: {point}', marker='x')

    # Add legend
    # ax.legend()

    # Show plot
    plt.show()

def gaussian_jittering_PI(x_train, y_train, n_aug=10, p_std=0.02, p_range=(0, 2), i_std=0.02, i_range=(0, 1)):
    # Define number of jittered samples per original sample
    n_aug_per_sample = n_aug

    # Split into P and I for processing
    P = x_train[:, 0]
    I = x_train[:, 1]

    # Generate jittered P, I values
    jittered_P = np.repeat(P, n_aug_per_sample) + np.random.normal(0, p_std, size=len(P) * n_aug_per_sample)
    jittered_I = np.repeat(I, n_aug_per_sample) + np.random.normal(0, i_std, size=len(P) * n_aug_per_sample)

    # Clip jittered P, I to valid range
    jittered_P = np.clip(jittered_P, p_range[0], p_range[1])
    jittered_I = np.clip(jittered_I, i_range[0], i_range[1])

    # Augmented x_train
    x_train_augmented = np.column_stack((jittered_P, jittered_I))

    # Train a model on original data
    regressor = RandomForestRegressor()
    regressor.fit(x_train, y_train)

    # Predict RMSE for new augmented (P, I)
    y_train_augmented = regressor.predict(x_train_augmented)

    return x_train_augmented, y_train_augmented

def gaussian_jittering_P(x_train, y_train, n_aug=5, j_std=0.02, j_range=(0, 2)):
    # Define number of jittered samples per original sample
    n_aug_per_sample = n_aug

    # Define jitter standard deviation
    jitter_std = j_std

    # Split into P and I for processing
    P = x_train[:, 0]
    I = x_train[:, 1]

    # Generate jittered P values
    jittered_P = np.repeat(P, n_aug_per_sample) + np.random.normal(0, jitter_std, size=len(P) * n_aug_per_sample)
    jittered_I = np.repeat(I, n_aug_per_sample)

    # Clip jittered P to valid range (e.g., 0–1)
    jittered_P = np.clip(jittered_P, j_range[0], j_range[1])

    # Augmented x_train
    x_train_augmented = np.column_stack((jittered_P, jittered_I))

    # Train a model on original data
    regressor = RandomForestRegressor()
    regressor.fit(x_train, y_train)

    # Predict RMSE for new augmented (P, I)
    y_train_augmented = regressor.predict(x_train_augmented)

    return x_train_augmented, y_train_augmented

def gaussian_jittering_I(x_train, y_train, n_aug=5, j_std=0.02, j_range=(0, 1)):
    # Define number of jittered samples per original sample
    n_aug_per_sample = n_aug

    # Define jitter standard deviation
    jitter_std = j_std

    # Split into P and I for processing
    P = x_train[:, 0]
    I = x_train[:, 1]

    # Generate jittered I values
    jittered_P = np.repeat(P, n_aug_per_sample)
    jittered_I = np.repeat(I, n_aug_per_sample) + np.random.normal(0, jitter_std, size=len(P) * n_aug_per_sample)

    # Clip jittered I to valid range (e.g., 0–1)
    jittered_I = np.clip(jittered_I, j_range[0], j_range[1])

    # Augmented x_train
    x_train_augmented = np.column_stack((jittered_P, jittered_I))

    # Train a model on original data
    regressor = RandomForestRegressor()
    regressor.fit(x_train, y_train)

    # Predict RMSE for new augmented (P, I)
    y_train_augmented = regressor.predict(x_train_augmented)

    return x_train_augmented, y_train_augmented

def gaussian_jittering_PI2(x_train, y_train, n_aug=3, p_std=0.02, p_range=(0, 2), i_std=0.02, i_range=(0, 1)):
    x_train_augmented, y_train_augmented = gaussian_jittering_I(x_train, y_train, n_aug=n_aug, j_std=i_std, j_range=i_range)
    x_train = np.vstack([x_train, x_train_augmented])
    y_train = np.concatenate([y_train, y_train_augmented])
    x_train_augmented, y_train_augmented = gaussian_jittering_P(x_train, y_train, n_aug=n_aug, j_std=p_std, j_range=p_range)
    # x_train = np.vstack([x_train, x_train_augmented])
    # y_train = np.concatenate([y_train, y_train_augmented])

    return x_train_augmented, y_train_augmented

def knn_regression(x_train, y_train, x_start, x_stop, x_step, y_start, y_stop, y_step, k_value=3, show_chart=False):
    # Create a k-NN regression model
    knn_model = KNeighborsRegressor(n_neighbors=k_value, weights='distance')
    knn_model.fit(x_train, y_train)

    # Generate grid points for prediction
    x_range = np.arange(x_start, x_stop + x_step, x_step)
    y_range = np.arange(y_start, y_stop + y_step, y_step)
    grid_x, grid_y = np.meshgrid(x_range, y_range)
    grid_points = np.column_stack([grid_x.ravel(), grid_y.ravel()])

    # Predict missing values using k-NN Regression
    predicted_values = knn_model.predict(grid_points)

    # Reshape to match the expanded table structure
    grid_z = predicted_values.reshape(grid_x.shape)

    # Create DataFrame with k-NN predictions
    df_filled_knn = pd.DataFrame(grid_z, index=y_range, columns=x_range)

    candidate_list = []
    candidate_size = 10
    # Find the minimum values and its coordinates
    sorted_indices = np.argsort(grid_z, axis=None)
    for i in range(0, candidate_size):
        min_index = sorted_indices[i]
        min_coords = np.unravel_index(min_index, grid_z.shape)
        min_value = round(grid_z[min_coords], 3)
        min_x, min_y = round(grid_x[min_coords], 7), round(grid_y[min_coords], 7)
        candidate_list.append((min_x, min_y, min_value))

    return df_filled_knn, candidate_list

def random_forest_regression(x_train, y_train, x_start, x_stop, x_step, y_start, y_stop, y_step, n_estimators=50, show_chart=False):
    # Create a Random Forest regression model
    rf_model = RandomForestRegressor(n_estimators=n_estimators)
    rf_model.fit(x_train, y_train)

    # Generate grid points for prediction
    x_range = np.arange(x_start, x_stop + x_step, x_step)
    y_range = np.arange(y_start, y_stop + y_step, y_step)
    grid_x, grid_y = np.meshgrid(x_range, y_range)
    grid_points = np.column_stack([grid_x.ravel(), grid_y.ravel()])

    # Predict missing values using Random Forest Regression
    predicted_values = rf_model.predict(grid_points)

    # Reshape to match the expanded table structure
    grid_z = predicted_values.reshape(grid_x.shape)

    # Create DataFrame with Random Forest predictions
    df_filled_rf = pd.DataFrame(grid_z, index=y_range, columns=x_range)

    candidate_list = []
    candidate_size = 10
    # Find the minimum values and its coordinates
    sorted_indices = np.argsort(grid_z, axis=None)
    for i in range(0, candidate_size):
        min_index = sorted_indices[i]
        min_coords = np.unravel_index(min_index, grid_z.shape)
        min_value = round(grid_z[min_coords], 3)
        min_x, min_y = round(grid_x[min_coords], 7), round(grid_y[min_coords], 7)
        candidate_list.append((min_x, min_y, min_value))

    return df_filled_rf, candidate_list

def ensemble_regression2(x_train, y_train, x_start, x_stop, x_step, y_start, y_stop, y_step, k_value=3, n_estimators=50, show_chart=False):
    # Create k-NN and Random Forest regression models
    knn_model = KNeighborsRegressor(n_neighbors=k_value, weights='distance')
    rf_model = RandomForestRegressor(n_estimators=n_estimators)

    # Create an ensemble model using VotingRegressor
    ensemble_model = VotingRegressor(estimators=[('knn', knn_model), ('rf', rf_model)])
    ensemble_model.fit(x_train, y_train)

    # Generate grid points for prediction
    x_range = np.arange(x_start, x_stop + x_step, x_step)
    y_range = np.arange(y_start, y_stop + y_step, y_step)
    grid_x, grid_y = np.meshgrid(x_range, y_range)
    grid_points = np.column_stack([grid_x.ravel(), grid_y.ravel()])

    # Predict missing values using the ensemble model
    predicted_values = ensemble_model.predict(grid_points)

    # Reshape to match the expanded table structure
    grid_z = predicted_values.reshape(grid_x.shape)

    # Create DataFrame with ensemble predictions
    df_filled_ensemble = pd.DataFrame(grid_z, index=y_range, columns=x_range)

    candidate_list = []
    candidate_size = 10
    # Find the minimum values and its coordinates
    sorted_indices = np.argsort(grid_z, axis=None)
    for i in range(0, candidate_size):
        min_index = sorted_indices[i]
        min_coords = np.unravel_index(min_index, grid_z.shape)
        min_value = round(grid_z[min_coords], 3)
        min_x, min_y = round(grid_x[min_coords], 7), round(grid_y[min_coords], 7)
        candidate_list.append((min_x, min_y, min_value))

    if show_chart:
        train_data = [[value1, value2, value3] for ([value1, value2], value3) in zip(x_train, y_train)]
        # plot_heatmap(x_range, y_range, grid_z)
        plot_3d_data(x_range, y_range, grid_z, train_data)

    return df_filled_ensemble, candidate_list

def ensemble_regression3(x_train, y_train, x_start, x_stop, x_step, y_start, y_stop, y_step, k_value=3, n_estimators=50, degree=3, kernel='rbf',show_chart=False):
    # Create individual regression models
    knn_model = KNeighborsRegressor(n_neighbors=k_value, weights='distance')
    rf_model = RandomForestRegressor(n_estimators=n_estimators)
    svr_model = Pipeline([
        ('scaler', StandardScaler()),
        ('svr', SVR(kernel=kernel))
    ])

    # Create an ensemble model using VotingRegressor
    ensemble_model = VotingRegressor(estimators=[
        ('knn', knn_model),
        ('rf', rf_model),
        ('svr', svr_model),
    ])
    ensemble_model.fit(x_train, y_train)

    # Generate grid points for prediction
    x_range = np.arange(x_start, x_stop + x_step, x_step)
    y_range = np.arange(y_start, y_stop + y_step, y_step)
    grid_x, grid_y = np.meshgrid(x_range, y_range)
    grid_points = np.column_stack([grid_x.ravel(), grid_y.ravel()])

    # Predict missing values using the ensemble model
    predicted_values = ensemble_model.predict(grid_points)

    # Reshape to match the expanded table structure
    grid_z = predicted_values.reshape(grid_x.shape)

    # Create DataFrame with ensemble predictions
    df_filled_ensemble = pd.DataFrame(grid_z, index=y_range, columns=x_range)

    candidate_list = []
    candidate_size = 10
    # Find the minimum values and its coordinates
    sorted_indices = np.argsort(grid_z, axis=None)
    for i in range(0, candidate_size):
        min_index = sorted_indices[i]
        min_coords = np.unravel_index(min_index, grid_z.shape)
        min_value = round(grid_z[min_coords], 3)
        min_x, min_y = round(grid_x[min_coords], 7), round(grid_y[min_coords], 7)
        candidate_list.append((min_x, min_y, min_value))

    if show_chart:
        train_data = [[value1, value2, value3] for ([value1, value2], value3) in zip(x_train, y_train)]
        # plot_heatmap(x_range, y_range, grid_z)
        # plot_3d_data(x_range, y_range, grid_z, train_data)
        plot_3d_data(x_range, y_range, grid_z)

    # SHAP values calculation
    explainer = shap.Explainer(ensemble_model)
    shap_values = explainer(x_train)

    # Plot SHAP values
    shap.summary_plot(shap_values, x_train, feature_names=["P", "I"])

    return df_filled_ensemble, candidate_list

def ensemble_regression3_feature_engineering(x_train, y_train, k_value=3, n_estimators=50, degree=2, kernel='rbf', cv=5, aug=False):
    # Augmentation for x_train, y_train
    if aug:
        x_train_augmented, y_train_augmented = gaussian_jittering_PI2(x_train, y_train)
        x_train = np.vstack([x_train, x_train_augmented])
        y_train = np.concatenate([y_train, y_train_augmented])

    # === Feature Engineering: Transformations ===
    feature_engineering = ColumnTransformer([
        ('log', FunctionTransformer(np.log1p), [0, 1]),
        ('sqrt', FunctionTransformer(np.sqrt), [0, 1]),
        ('poly', PolynomialFeatures(degree=2, interaction_only=True, include_bias=False), [0, 1])
    ])

    # === Models ===
    rf_model = RandomForestRegressor(n_estimators=n_estimators)
    knn_model = Pipeline([
        ('scaler', StandardScaler()),
        ('knn', KNeighborsRegressor(n_neighbors=k_value, weights='distance'))
    ])
    svr_model = Pipeline([
        ('scaler', StandardScaler()),
        ('svr', SVR(kernel=kernel))
    ])

    # === Ensemble with Voting Regressor ===
    ensemble_model = VotingRegressor(estimators=[
        ('knn', knn_model),
        ('rf', rf_model),
        ('svr', svr_model),
    ])

    # === Full Pipeline: Feature Engineering → Ensemble Model ===
    full_model = Pipeline([
        ('features', feature_engineering),
        ('ensemble', ensemble_model)
    ])

    # === Grid Search on full_model params ===
    param_grid = {
        'ensemble__knn__knn__n_neighbors': [3, 5, 7, 9],
        # 'ensemble__knn__knn__n_neighbors': [3, 5, 7],
        # 'ensemble__knn__knn__n_neighbors': [3, 5],
        'ensemble__rf__n_estimators': [50, 100, 150]
    }

    grid_search = GridSearchCV(full_model, param_grid, cv=cv, scoring='neg_mean_squared_error')
    grid_search.fit(x_train, y_train)

    best_params = grid_search.best_params_
    # print(f"Best parameters: {best_params}")

    # Update best params
    knn_model.set_params(knn__n_neighbors=best_params['ensemble__knn__knn__n_neighbors'])
    rf_model.set_params(n_estimators=best_params['ensemble__rf__n_estimators'])

    # Rebuild final pipeline with updated models
    final_model = Pipeline([
        ('features', feature_engineering),
        ('ensemble', VotingRegressor(estimators=[
            ('knn', knn_model),
            ('rf', rf_model),
            ('svr', svr_model),
        ]))
    ])

    # === Train Final Model ===
    final_model.fit(x_train, y_train)
   
    return final_model, x_train, y_train

def pid_regression(x_train, y_train, p_range=(0.1,2.0), i_range=(0.1,1.0),
                    steps=0.1, load_path="ensemble_model.joblib", 
                    use_finetune=True, save_path=None, **kwargs):

    x_start, x_stop = p_range
    y_start, y_stop = i_range
    x_step = 0.02
    y_step = 0.01

    model = load(load_path)

    # model = fine_tune_ensemble(x_train, y_train, load_path=load_path, save_path=save_path)
    # model, x_train, y_train = ensemble_regression3_feature_engineering(x_train, y_train, aug=True)

    # Generate grid points for prediction
    x_range = np.arange(x_start, x_stop + x_step, x_step)
    y_range = np.arange(y_start, y_stop + y_step, y_step)
    grid_x, grid_y = np.meshgrid(x_range, y_range)
    grid_points = np.column_stack([grid_x.ravel(), grid_y.ravel()])

    # Predict missing values using the ensemble model
    predicted_values = model.predict(grid_points)

    # Reshape to match the expanded table structure
    grid_z = predicted_values.reshape(grid_x.shape)

    # Create DataFrame with ensemble predictions
    df_filled_ensemble = pd.DataFrame(grid_z, index=y_range, columns=x_range)

    # Round values to 4 decimal places
    df_filled_ensemble.columns = [round(float(col), 4) for col in df_filled_ensemble.columns]
    df_filled_ensemble.index = [round(float(idx), 4) for idx in df_filled_ensemble.index]
    df_filled_ensemble = df_filled_ensemble.round(4)

    # Save the DataFrame as a CSV file in table style
    df_filled_ensemble.to_csv("predicted_table.csv")

    candidate_list = []
    candidate_size = 20
    # Find the minimum values and its coordinates
    sorted_indices = np.argsort(grid_z, axis=None)
    for i in range(0, candidate_size):
        min_index = sorted_indices[i]
        min_coords = np.unravel_index(min_index, grid_z.shape)
        min_value = round(grid_z[min_coords], 3)
        min_x, min_y = round(grid_x[min_coords], 7), round(grid_y[min_coords], 7)
        candidate_list.append((min_x, min_y, min_value))

    show_chart = False
    # show_chart = True
    if show_chart:
        train_data = [[value1, value2, value3] for ([value1, value2], value3) in zip(x_train, y_train)]
        # plot_heatmap(x_range, y_range, grid_z)
        # plot_3d_data(x_range, y_range, grid_z, train_data)
        plot_3d_data(x_range, y_range, grid_z)

    return df_filled_ensemble, candidate_list

