# Validatioin of Augmented Data using LLM with ROC-AUC and Confusion Matrix plots

import json
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, silhouette_score, roc_curve, auc, confusion_matrix, ConfusionMatrixDisplay
import matplotlib.pyplot as plt

# 1. Load your data

data_path = "./2025-03-24_train1/augmented/05/"
org_file = data_path + "fewshot_n5.json"
aug_file = data_path + "aug_n10.json"

with open(org_file, 'r') as f:
    original = json.load(f)

with open(aug_file, 'r') as f:
    augmented = json.load(f)

# 2. Build DataFrames and label them

df_orig = pd.DataFrame(original)
df_orig['label'] = 0  # real

df_aug = pd.DataFrame(augmented)
df_aug['label'] = 1  # synthetic

df = pd.concat([df_orig, df_aug], ignore_index=True)

# 3. Select features and labels

features = df[['P', 'I', 'RMSE_SV_PV']].values
labels = df['label'].values

# 4. Standardize features

scaler = StandardScaler()
X_scaled = scaler.fit_transform(features)

# 5. Split into train/test for discriminator

X_train, X_test, y_train, y_test = train_test_split(
    X_scaled, labels, test_size=0.3, random_state=42, stratify=labels
)

# 6. Train a lightweight discriminator (logistic regression)

clf = LogisticRegression(solver='liblinear', random_state=42)
clf.fit(X_train, y_train)

# 7. Evaluate discriminator

y_pred = clf.predict(X_test)
y_pred_proba = clf.predict_proba(X_test)[:, 1]
acc = accuracy_score(y_test, y_pred)
print(f"Discriminator accuracy (orig vs aug): {acc:.3f}")

# 8. Plot ROC Curve and compute AUC

fpr, tpr, thresholds = roc_curve(y_test, y_pred_proba)
roc_auc = auc(fpr, tpr)
plt.figure()
plt.plot(fpr, tpr, label=f'ROC curve (AUC = {roc_auc:.2f})')
plt.plot([0, 1], [0, 1], linestyle='--', label='Random chance')
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('ROC Curve for Discriminator')
plt.legend(loc='lower right')
plt.show()

# 9. Plot Confusion Matrix

cm = confusion_matrix(y_test, y_pred)
disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=clf.classes_)
fig, ax = plt.subplots()
disp.plot(ax=ax, cmap=plt.cm.Blues)
plt.title('Confusion Matrix for Discriminator')
plt.show()

# 10. Compute silhouette score

sil_score = silhouette_score(X_scaled, labels, metric='euclidean')
print(f"Silhouette score (orig vs aug clusters): {sil_score:.3f}")
