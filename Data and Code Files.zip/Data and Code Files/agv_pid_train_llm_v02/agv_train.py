########################################################################################
# Title: PID Training using AGV tracking data.
# Version: 1.0
# Date: 2025-03-18
# Description: This script is used to train AGV tracking data using ensemble models.
########################################################################################
from joblib import dump
import pandas as pd
import numpy as np
import os, glob
import time

from sklearn.linear_model import LinearRegression, Ridge, Lasso
from sklearn.neighbors import KNeighborsRegressor
from sklearn.ensemble import RandomForestRegressor, VotingRegressor, StackingRegressor
from sklearn.model_selection import cross_val_score, GridSearchCV
from sklearn.preprocessing import PolynomialFeatures, StandardScaler, FunctionTransformer
from sklearn.linear_model import HuberRegressor
from sklearn.pipeline import Pipeline
from sklearn.pipeline import make_pipeline
from sklearn.svm import SVR
from sklearn.ensemble import GradientBoostingRegressor, ExtraTreesRegressor
from sklearn.compose import ColumnTransformer

import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import shap
from lime.lime_tabular import LimeTabularExplainer
import webbrowser

from agv_dataprocess import agv_analysis_csv, agv_make_train_data, print_csv_format, list_csv_files
from agv_regressions import gaussian_jittering_PI, ensemble_regression3_feature_engineering

def list_csv_files_multipath(folders, randomize=False):
    csv_files = []
    for folder_path in folders:
        csv_files += list_csv_files(folder_path, randomize)

    return csv_files

def ensemble_train_feature_engineering2(x_train, y_train, k_value=3, n_estimators=50, degree=2, kernel='rbf', cv=5):
    x_train = np.array(x_train)  # Shape: (n_samples, 2)

    # === Feature Engineering: Transformations ===
    feature_engineering = ColumnTransformer([
        ('log', FunctionTransformer(np.log1p), [0, 1]),
        ('sqrt', FunctionTransformer(np.sqrt), [0, 1]),
        ('poly', PolynomialFeatures(degree=2, interaction_only=True, include_bias=False), [0, 1])
    ])

    # === Models ===
    rf_model = RandomForestRegressor(n_estimators=n_estimators)
    knn_model = Pipeline([
        ('scaler', StandardScaler()),
        ('knn', KNeighborsRegressor(n_neighbors=k_value, weights='distance'))
    ])
    svr_model = Pipeline([
        ('scaler', StandardScaler()),
        ('svr', SVR(kernel=kernel))
    ])

    # === Ensemble with Voting Regressor ===
    ensemble_model = VotingRegressor(estimators=[
        ('knn', knn_model),
        ('rf', rf_model),
        ('svr', svr_model),
    ])

    # === Full Pipeline: Feature Engineering → Ensemble Model ===
    full_model = Pipeline([
        ('features', feature_engineering),
        ('ensemble', ensemble_model)
    ])

    # === Grid Search on full_model params ===
    param_grid = {
        'ensemble__knn__knn__n_neighbors': [3, 5, 7, 9],
        'ensemble__rf__n_estimators': [50, 100, 150]
    }

    grid_search = GridSearchCV(full_model, param_grid, cv=cv, scoring='neg_mean_squared_error')
    grid_search.fit(x_train, y_train)

    best_params = grid_search.best_params_
    # print(f"Best parameters: {best_params}")

    # Update best params
    knn_model.set_params(knn__n_neighbors=best_params['ensemble__knn__knn__n_neighbors'])
    rf_model.set_params(n_estimators=best_params['ensemble__rf__n_estimators'])

    # Rebuild final pipeline with updated models
    final_model = Pipeline([
        ('features', feature_engineering),
        ('ensemble', VotingRegressor(estimators=[
            ('knn', knn_model),
            ('rf', rf_model),
            ('svr', svr_model),
        ]))
    ])

    # === Train Final Model ===
    final_model.fit(x_train, y_train)

    # === Cross-Validated Evaluation ===
    scores = {}
    cv_scores = cross_val_score(final_model, x_train, y_train, cv=cv, scoring='neg_mean_squared_error')
    scores['MSE'] = round(-cv_scores.mean(), 4)
    scores['RMSE'] = round(np.sqrt(scores['MSE']), 4)
    cv_scores = cross_val_score(final_model, x_train, y_train, cv=cv, scoring='neg_mean_absolute_error')
    scores['MAE'] = round(-cv_scores.mean(), 4)
    cv_scores = cross_val_score(final_model, x_train, y_train, cv=cv, scoring='r2')
    scores['R2'] = round(cv_scores.mean(), 4)

    return scores

def ensemble_train(x_train, y_train, k_value=3, n_estimators=50, degree=3, kernel='rbf',cv=5):
    # === Models ===
    rf_model = RandomForestRegressor(n_estimators=n_estimators)
    knn_model = Pipeline([
        ('scaler', StandardScaler()),
        ('knn', KNeighborsRegressor(n_neighbors=k_value, weights='distance'))
    ])
    svr_model = Pipeline([
        ('scaler', StandardScaler()),
        ('svr', SVR(kernel=kernel))
    ])

    # === Ensemble with Voting Regressor ===
    ensemble_model = VotingRegressor(estimators=[
        ('knn', knn_model),
        ('rf', rf_model),
        ('svr', svr_model),
    ])
    
    # Train the ensemble model
    ensemble_model.fit(x_train, y_train)
    
    scores = {}
    # Validate the model using cross-validation
    cv_scores = cross_val_score(ensemble_model, x_train, y_train, cv=cv, scoring='neg_mean_squared_error')
    scores['MSE'] = round(-cv_scores.mean(), 4)
    scores['RMSE'] = round(np.sqrt(scores['MSE']), 4)
    cv_scores = cross_val_score(ensemble_model, x_train, y_train, cv=cv, scoring='neg_mean_absolute_error')
    scores['MAE'] = round(-cv_scores.mean(), 4)
    cv_scores = cross_val_score(ensemble_model, x_train, y_train, cv=cv, scoring='r2')
    scores['R2'] = round(cv_scores.mean(), 4)
    
    return scores

def ensemble_train_feature_engineering(x_train, y_train, k_value=3, n_estimators=50, degree=2, kernel='rbf', cv=5):
    # === Feature Engineering: Polynomial Feature Expansion ===
    feature_engineering = PolynomialFeatures(degree=degree, include_bias=False)

    # === Models ===
    rf_model = RandomForestRegressor(n_estimators=n_estimators)
    knn_model = Pipeline([
        ('scaler', StandardScaler()),
        ('knn', KNeighborsRegressor(n_neighbors=k_value, weights='distance'))
    ])
    svr_model = Pipeline([
        ('scaler', StandardScaler()),
        ('svr', SVR(kernel=kernel))
    ])

    # === Ensemble with Voting Regressor ===
    ensemble_model = VotingRegressor(estimators=[
        ('knn', knn_model),
        ('rf', rf_model),
        ('svr', svr_model),
    ])

    # === Full Pipeline: Feature Engineering → Ensemble Model ===
    full_model = Pipeline([
        ('features', feature_engineering),
        ('ensemble', ensemble_model)
    ])

    # === Grid Search on full_model params ===
    param_grid = {
        'ensemble__knn__knn__n_neighbors': [3, 5, 7, 9, 11],
        'ensemble__rf__n_estimators': [50, 100, 150]
    }

    grid_search = GridSearchCV(full_model, param_grid, cv=cv, scoring='neg_mean_squared_error')
    grid_search.fit(x_train, y_train)

    best_params = grid_search.best_params_
    # print(f"Best parameters: {best_params}")

    # Update best params
    knn_model.set_params(knn__n_neighbors=best_params['ensemble__knn__knn__n_neighbors'])
    rf_model.set_params(n_estimators=best_params['ensemble__rf__n_estimators'])

    # Rebuild final pipeline with updated models
    final_model = Pipeline([
        ('features', feature_engineering),
        ('ensemble', VotingRegressor(estimators=[
            ('knn', knn_model),
            ('rf', rf_model),
            ('svr', svr_model),
        ]))
    ])

    # === Train Final Model ===
    final_model.fit(x_train, y_train)

    # === Cross-Validated Evaluation ===
    scores = {}
    cv_scores = cross_val_score(final_model, x_train, y_train, cv=cv, scoring='neg_mean_squared_error')
    scores['MSE'] = round(-cv_scores.mean(), 4)
    scores['RMSE'] = round(np.sqrt(scores['MSE']), 4)
    cv_scores = cross_val_score(final_model, x_train, y_train, cv=cv, scoring='neg_mean_absolute_error')
    scores['MAE'] = round(-cv_scores.mean(), 4)
    cv_scores = cross_val_score(final_model, x_train, y_train, cv=cv, scoring='r2')
    scores['R2'] = round(cv_scores.mean(), 4)

    return scores

def gaussian_jittering_P(x_train, y_train, n_aug=5, j_std=0.02, j_range=(0, 2)):
    # Define number of jittered samples per original sample
    n_aug_per_sample = n_aug

    # Define jitter standard deviation
    jitter_std = j_std

    # Split into P and I for processing
    P = x_train[:, 0]
    I = x_train[:, 1]

    # Generate jittered P values
    jittered_P = np.repeat(P, n_aug_per_sample) + np.random.normal(0, jitter_std, size=len(P) * n_aug_per_sample)
    jittered_I = np.repeat(I, n_aug_per_sample)

    # Clip jittered P to valid range (e.g., 0–1)
    jittered_P = np.clip(jittered_P, j_range[0], j_range[1])

    # Augmented x_train
    x_train_augmented = np.column_stack((jittered_P, jittered_I))

    # Train a model on original data
    regressor = RandomForestRegressor()
    regressor.fit(x_train, y_train)

    # Predict RMSE for new augmented (P, I)
    y_train_augmented = regressor.predict(x_train_augmented)

    return x_train_augmented, y_train_augmented

def gaussian_jittering_I(x_train, y_train, n_aug=5, j_std=0.02, j_range=(0, 1)):
    # Define number of jittered samples per original sample
    n_aug_per_sample = n_aug

    # Define jitter standard deviation
    jitter_std = j_std

    # Split into P and I for processing
    P = x_train[:, 0]
    I = x_train[:, 1]

    # Generate jittered I values
    jittered_P = np.repeat(P, n_aug_per_sample)
    jittered_I = np.repeat(I, n_aug_per_sample) + np.random.normal(0, jitter_std, size=len(P) * n_aug_per_sample)

    # Clip jittered I to valid range (e.g., 0–1)
    jittered_I = np.clip(jittered_I, j_range[0], j_range[1])

    # Augmented x_train
    x_train_augmented = np.column_stack((jittered_P, jittered_I))

    # Train a model on original data
    regressor = RandomForestRegressor()
    regressor.fit(x_train, y_train)

    # Predict RMSE for new augmented (P, I)
    y_train_augmented = regressor.predict(x_train_augmented)

    return x_train_augmented, y_train_augmented

def ensemble_train_feature_engineering_xai(x_train, y_train, k_value=3,
                                            n_estimators=50, degree=2, kernel='rbf', 
                                            cv=5, aug=False, xai=False, show=False):
    final_model, x_train, y_train = ensemble_regression3_feature_engineering(x_train, y_train, aug=aug)
    # —— persist the trained ensemble for later reuse ——
    dump(final_model, "ensemble_model.joblib")
    print(">> saved ensemble_model.joblib")






    # === Cross-Validated Evaluation ===
    scores = {}
    cv_scores = cross_val_score(final_model, x_train, y_train, cv=cv, scoring='neg_mean_squared_error')
    scores['MSE'] = round(-cv_scores.mean(), 4)
    scores['RMSE'] = round(np.sqrt(scores['MSE']), 4)
    cv_scores = cross_val_score(final_model, x_train, y_train, cv=cv, scoring='neg_mean_absolute_error')
    scores['MAE'] = round(-cv_scores.mean(), 4)
    cv_scores = cross_val_score(final_model, x_train, y_train, cv=cv, scoring='r2')
    scores['R2'] = round(cv_scores.mean(), 4)

    if xai:
        # SHAP values calculation using KernelExplainer
        explainer = shap.KernelExplainer(final_model.predict, x_train)
        shap_values = explainer.shap_values(x_train)

        if show:
            # SHAP explanation AI
            # shap.summary_plot(shap_values, x_train, feature_names=["P", "I"])
            # shap.dependence_plot("P", shap_values, x_train, feature_names=["P", "I"])
            # shap.dependence_plot("I", shap_values, x_train, feature_names=["P", "I"])

            shapfolder = "./shap"
            os.makedirs(shapfolder, exist_ok=True)
            # Save SHAP summary plot as an image
            plt.figure()
            shap.summary_plot(shap_values, x_train, feature_names=["P", "I"], show=False)
            plt.savefig(os.path.join(shapfolder, "shap_summary_plot.png"), bbox_inches='tight')
            plt.close()

            # Save SHAP dependence plots as images
            plt.figure()
            shap.dependence_plot("P", shap_values, x_train, feature_names=["P", "I"], show=False)
            plt.savefig(os.path.join(shapfolder, "shap_dependence_plot_P.png"), bbox_inches='tight')
            plt.close()

            plt.figure()
            shap.dependence_plot("I", shap_values, x_train, feature_names=["P", "I"], show=False)
            plt.savefig(os.path.join(shapfolder, "shap_dependence_plot_I.png"), bbox_inches='tight')
            plt.close()

        """
        # LIME explanation for a single instance
        lime_explainer = LimeTabularExplainer(x_train, feature_names=["P", "I"], class_names=["RMSE"], mode='regression')
        instance = x_train[0]  # Example instance
        lime_exp = lime_explainer.explain_instance(instance, final_model.predict)
        # lime_exp.show_in_notebook(show_table=True)
        # Save LIME explanation to HTML file
        lime_html_path = "lime_explanation.html"
        lime_exp.save_to_file(lime_html_path)

        # Open the HTML file in the default web browser
        webbrowser.open(lime_html_path)
        """
   
    return scores

def pid_train(csv_files, num_files=None, split=1, xai=False, debug=False):
    if not num_files is None:
        csv_files = csv_files[:num_files if num_files < len(csv_files) else len(csv_files)]

    results = []
    for file in csv_files:
        results += agv_analysis_csv(file, split=split)

    param = "RMSE_SV_PV"
    param = "RMSE_SV"
    # param = "RMSE_PV"
    # param = "EG"
    x_train, y_train = agv_make_train_data(param, results)
    # aug = False
    aug = True
    if xai:
        scores = ensemble_train_feature_engineering_xai(x_train, y_train, aug=aug, xai=xai, show=True)
    else:
        scores = ensemble_train_feature_engineering_xai(x_train, y_train, aug=aug)
    # scores = ensemble_train_feature_engineering2(x_train, y_train)
    print(f"[{param}] Cross-validated scores: {scores}")

    # x_train, y_train = agv_make_train_data("MAE_SV_PV", results)
    # # scores = ensemble_train(x_train, y_train)
    # scores = ensemble_train_feature_engineering(x_train, y_train)
    # print(f"[MAE] Cross-validated scores: {scores}")

    return scores


###########################################################################################################

if __name__ == "__main__":

    path_5m = ["./2025-03-24_train1/all/05"]
    path_10m = ["./2025-03-24_train1/all/10"]
    path_15m = ["./2025-03-24_train1/all/15"]
    path_20m = ["./2025-03-24_train1/all/20"]
    path_25m = ["./2025-03-24_train1/all/25"]

    #path_5m = ["./2025-03-24/05"]
    #path_10m = ["./2025-03-24/10"]
    #path_15m = ["./2025-03-24/15"]
    #path_20m = ["./2025-03-24/20"]
    #path_25m = ["./2025-03-24/25"]
    
    # path_5m = ["./2025-03-24_train1/single/05"]
    # path_10m = ["./2025-03-24_train1/single/10"]
    # path_15m = ["./2025-03-24_train1/single/15"]
    # path_20m = ["./2025-03-24_train1/single/20"]
    # path_25m = ["./2025-03-24_train1/single/25"]

    #path_5m = ["./2025-03-13/05"]
    #path_10m = ["./2025-03-13/10"]
    #path_15m = ["./2025-03-13/15"]
    #path_20m = ["./2025-03-13/20"]
    #path_25m = ["./2025-03-13/25"]

    randomize = False
    # randomize = True
    base_len = None
    # base_len = 20
    # base_len = 10
    # base_len = 5
    # base_len = 3
    split = 1
    split = 2
    split = 4
    split = 8
    split = 12
    split = 16

    def main():
        
        # datapath = path_5m
        # datapath = path_10m
        # datapath = path_15m
        # datapath = path_20m
        # datapath = path_25m
        # datapaths = [path_5m, path_10m, path_15m, path_20m, path_25m]
        datapaths = [path_5m]

        base_len = None
        # base_lens = [15, 20, 25, 30, None]
        # base_lens = [25, 30, None]
        base_lens = [None]
        # for base_len in base_lens:
        #     print(f"<Samples={base_len}>")

        scores_all = []
        for datapath in datapaths:
            print(f"<Path={datapath}>")

            scores_each = []
            for i in range(1):
                csv_files = list_csv_files_multipath(datapath, randomize=randomize)
                scores_each.append(pid_train(csv_files, num_files=base_len, split=1, xai=True))
                # scores_each.append(pid_train(csv_files, num_files=base_len, split=1))
            scores_all += scores_each

        avg_scores = {}
        avg_scores["MSE"] = round(np.mean([scores['MSE'] for scores in scores_all]), 4)
        avg_scores["RMSE"] = round(np.mean([scores['RMSE'] for scores in scores_all]), 4)
        avg_scores["MAE"] = round(np.mean([scores['MAE'] for scores in scores_all]), 4)
        avg_scores["R2"] = round(np.mean([scores['R2'] for scores in scores_all]), 4)
        print(f"AVG: {avg_scores}")


    main()