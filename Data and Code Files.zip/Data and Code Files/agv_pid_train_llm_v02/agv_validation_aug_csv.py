# Validatioin of Augmented Data using LLM.

import json
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, silhouette_score
from sklearn.svm import SVR
from sklearn.metrics import mean_squared_error

data_path = "./2025-03-24_train1/augmented/05/"
org_file = data_path + "org_pred.csv"
# aug_file = data_path + "aug_n10.json"
# aug_file = data_path + "aug_n59.json"
aug_file = data_path + "aug_n5.json"

df_orig = pd.read_csv(org_file, index_col=0)
df_orig.index.name = 'I'  # Ensure the index has a name for melt
df_orig = df_orig.reset_index().melt(id_vars='I', var_name='P', value_name='RMSE_SV_PV')

# Filter out any rows where P or I are not numeric
df_orig = df_orig[pd.to_numeric(df_orig['P'], errors='coerce').notnull()]
df_orig = df_orig[pd.to_numeric(df_orig['I'], errors='coerce').notnull()]

df_orig['P'] = df_orig['P'].astype(float)
df_orig['I'] = df_orig['I'].astype(float)
df_orig['label'] = 0  # real

with open(aug_file, 'r') as f:
    augmented = json.load(f)

df_aug = pd.DataFrame(augmented)
df_aug['label'] = 1  # synthetic

df = pd.concat([df_orig, df_aug], ignore_index=True)

# 3. Select features and labels
features = df[['P', 'I', 'RMSE_SV_PV']].values
labels = df['label'].values

# 4. Standardize features
scaler = StandardScaler()
X_scaled = scaler.fit_transform(features)

# 5. Split into train/test for discriminator
X_train, X_test, y_train, y_test = train_test_split(
    X_scaled, labels, test_size=0.3, random_state=42, stratify=labels
)

# 6. Train a regression model (SVR) to predict label (0 or 1)
reg = SVR(kernel='rbf')
reg.fit(X_train, y_train)

# 7. Evaluate regression
y_pred = reg.predict(X_test)
mse = mean_squared_error(y_test, y_pred)
print(f"SVR regression MSE (orig vs aug): {mse:.4f}")

# 8. Compute silhouette score on the combined data
sil_score = silhouette_score(X_scaled, labels, metric='euclidean')
print(f"Silhouette score (orig vs aug clusters): {sil_score:.3f}")

# Interpretation:
# - A lower MSE suggests the SVR cannot easily distinguish between original and augmented data.
# - A silhouette score near 0 indicates that points from the two groups are well-mixed;
#   larger positive values (up to 1) indicate more separation.
