# Validatioin of Augmented Data using LLM.

import json
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, silhouette_score
from sklearn.svm import SVR
from sklearn.metrics import mean_squared_error

data_path = "./2025-03-24_train1/augmented/05/"
# org_file = data_path + "fewshot_n5.json"
# org_file = data_path + "org_single.json"
org_file = data_path + "org_full.json"
aug_file = data_path + "aug_n10.json"
# aug_file = data_path + "aug_n59.json"
# aug_file = data_path + "aug_n5.json"

# 1. Load your data
with open(org_file, 'r') as f:
    original = json.load(f)

with open(aug_file, 'r') as f:
    augmented = json.load(f)

# 2. Build DataFrames and label them
df_orig = pd.DataFrame(original)
df_orig['label'] = 0  # real

df_aug = pd.DataFrame(augmented)
df_aug['label'] = 1  # synthetic

df = pd.concat([df_orig, df_aug], ignore_index=True)

# 3. Select features and labels
features = df[['P', 'I', 'RMSE_SV_PV']].values
labels = df['label'].values

# 4. Standardize features
scaler = StandardScaler()
X_scaled = scaler.fit_transform(features)

# 5. Split into train/test for discriminator
X_train, X_test, y_train, y_test = train_test_split(
    X_scaled, labels, test_size=0.3, random_state=42, stratify=labels
)

# 6. Train a regression model (SVR) to predict label (0 or 1)
reg = SVR(kernel='rbf')
reg.fit(X_train, y_train)

# 7. Evaluate regression
y_pred = reg.predict(X_test)
mse = mean_squared_error(y_test, y_pred)
print(f"SVR regression MSE (orig vs aug): {mse:.4f}")

# 8. Compute silhouette score on the combined data
#    silhouette_score expects at least 2 labels in the data,
#    so here labels (0 vs 1) are fine.
sil_score = silhouette_score(X_scaled, labels, metric='euclidean')
print(f"Silhouette score (orig vs aug clusters): {sil_score:.3f}")

# Interpretation:
# - A lower MSE suggests the SVR cannot easily distinguish between original and augmented data.
# - A silhouette score near 0 indicates that points from the two groups are well-mixed;
#   larger positive values (up to 1) indicate more separation.
