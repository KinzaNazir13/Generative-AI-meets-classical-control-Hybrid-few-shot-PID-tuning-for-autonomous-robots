import json
from scipy.stats import ks_2samp

data_path = "./2025-03-24_train1/augmented/05/"
org_file = data_path + "fewshot_n5.json"
# org_file = data_path + "org_single.json"
# org_file = data_path + "org_full.json"
aug_file = data_path + "aug_n10.json"
# aug_file = data_path + "aug_n59.json"
# aug_file = data_path + "aug_n5.json"

# Load original and augmented datasets
with open(org_file, 'r') as f:
    original_data = json.load(f)

with open(aug_file, 'r') as f:
    augmented_data = json.load(f)

# Features to test
features = ['P', 'I', 'RMSE_SV_PV']

print("Kolmogorov–Smirnov Test Results:")
for feat in features:
    orig_vals = [sample[feat] for sample in original_data]
    aug_vals = [sample[feat] for sample in augmented_data]
    stat, p_value = ks_2samp(orig_vals, aug_vals)
    print(f"- {feat}: statistic = {stat:.4f}, p-value = {p_value:.4f}")

# Interpretation hint:
# A high p-value (e.g., > 0.05) means we cannot reject the null hypothesis
# that the two samples come from the same distribution.
