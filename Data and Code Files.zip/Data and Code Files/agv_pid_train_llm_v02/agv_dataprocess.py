########################################################################################
# Title: AGV Data Processing
# Version: 1.1
# Date: 2025-03-19
# Description: This script is used to process AGV data for analysis and prediction.
########################################################################################

import pandas as pd
import numpy as np
import os, glob
import time
import re, math
import warnings

from sklearn.preprocessing import StandardScaler


warnings.filterwarnings("ignore", category=FutureWarning, message=".*swapaxes.*")


def rmse(dfv, x, y):
    return np.sqrt(np.mean((dfv[x] - dfv[y]) ** 2))


def mae(dfv, x, y):
    return np.mean(np.abs(dfv[x] - dfv[y]))

def agv_analysis_csv(file_path, split=1):
    
    df_all = pd.read_csv(file_path)

    
    df_parts = np.array_split(df_all, split)
    

    
    P_value = df_all["P"].iloc[0]
    I_value = df_all["I"].iloc[0]
    D_value = df_all["D"].iloc[0]

    
    results = []
    for df in df_parts:
        
        RMSE_SV_L_PV_L = rmse(df, "SV_L", "PV_L")
        RMSE_SV_R_PV_R = rmse(df, "SV_R", "PV_R")
        RMSE_SV_PV = (RMSE_SV_L_PV_L + RMSE_SV_R_PV_R) / 2
        RMSE_SV_L_MV_L = rmse(df, "SV_L", "MV_L")
        RMSE_SV_R_MV_R = rmse(df, "SV_R", "MV_R")
        RMSE_SV_MV = (RMSE_SV_L_MV_L + RMSE_SV_R_MV_R) / 2
        MAE_SV_L_PV_L = mae(df, "SV_L", "PV_L")
        MAE_SV_R_PV_R = mae(df, "SV_R", "PV_R")
        MAE_SV_PV = (MAE_SV_L_PV_L + MAE_SV_R_PV_R) / 2
        MAE_SV_L_MV_L = mae(df, "SV_L", "MV_L")
        MAE_SV_R_MV_R = mae(df, "SV_R", "MV_R")
        MAE_SV_MV = (MAE_SV_L_MV_L + MAE_SV_R_MV_R) / 2
        RMSE = (RMSE_SV_PV + RMSE_SV_MV) / 2
        MAE = (MAE_SV_PV + MAE_SV_MV) / 2
        RMSE_MAE_PV = (RMSE_SV_PV + MAE_SV_PV) / 2
        RMSE_MAE_MV = (RMSE_SV_MV + MAE_SV_MV) / 2

        try:
            EG = np.sqrt(np.mean((df['EG'] - 1) ** 2))
        except:
            EG = 0

        RMSE_SV_L = np.sqrt(np.mean((df['SV_L']) ** 2))
        RMSE_SV_R = np.sqrt(np.mean((df['SV_R']) ** 2))
        RMSE_SV = (RMSE_SV_L + RMSE_SV_R) / 2
        RMSE_PV_L = np.sqrt(np.mean((df['PV_L']) ** 2))
        RMSE_PV_R = np.sqrt(np.mean((df['PV_R']) ** 2))
        RMSE_PV = (RMSE_PV_L + RMSE_PV_R) / 2
        
        result = {
            "P": P_value,
            "I": I_value,
            "D": D_value,
            "RMSE_SV_L_PV_L": RMSE_SV_L_PV_L,
            "RMSE_SV_R_PV_R": RMSE_SV_R_PV_R,
            "RMSE_SV_PV": RMSE_SV_PV,
            "RMSE_SV": RMSE_SV,
            "RMSE_PV": RMSE_PV,
            "RMSE_SV_L_MV_L": RMSE_SV_L_MV_L,
            "RMSE_SV_R_MV_R": RMSE_SV_R_MV_R,
            "RMSE_SV_MV": RMSE_SV_MV,
            "MAE_SV_L_PV_L": MAE_SV_L_PV_L,
            "MAE_SV_R_PV_R": MAE_SV_R_PV_R,
            "MAE_SV_PV": MAE_SV_PV,
            "MAE_SV_L_MV_L": MAE_SV_L_MV_L,
            "MAE_SV_R_MV_R": MAE_SV_R_MV_R,
            "MAE_SV_MV": MAE_SV_MV,
            "RMSE": RMSE,
            "MAE": MAE,
            "RMSE_MAE_PV": RMSE_MAE_PV,
            "RMSE_MAE_MV": RMSE_MAE_MV,
            "EG": EG,
        }

        results.append(result)

    return results

def agv_make_train_data(param_name, results):
    x_train = []
    y_train = []
    for data_dict in results:
        # x_train.append((data_dict["P"], data_dict["I"], data_dict["D"]))
        x_train.append([data_dict["P"], data_dict["I"]])
        y_train.append(data_dict[param_name])

    # """
    # Convert to numpy arrays for normalization
    x_train = np.array(x_train)
    y_train = np.array(y_train).reshape(-1, 1)
    
    # Normalize the data
    scaler_y = StandardScaler()
    y_train = scaler_y.fit_transform(y_train).flatten()
    #"""
    
    return x_train, y_train

def print_csv_format(results):
    dict_data = results[0]
    for key, value in dict_data.items():
        print(f"{key},", end="")
    print()  

    for dict_data in results:
        for key, value in dict_data.items():
            print(f"{value},", end="")
        print()  

def list_csv_files(folder_path, sorted=False, randomize=False):
    # Get all .csv files in the folder
    all_csv_files = glob.glob(os.path.join(folder_path, "*.csv"))
    
    # Exclude files that start with '-'
    filtered_csv_files = [file for file in all_csv_files if not os.path.basename(file).startswith('-')]
    
    if randomize:
        seed = int(time.time())  # Use current time as seed
        np.random.seed(seed)
        np.random.shuffle(filtered_csv_files)
    elif sorted:
        # Sort the list of files based on the starting number in the file name
        filtered_csv_files = sorted(filtered_csv_files, key=lambda x: int(os.path.basename(x).split('_')[0]))
    
    return filtered_csv_files

def get_file_pid_dicts(folder_path, randomize=False):
    def extract_params_from_filename(filename):
        # Extract the 2nd and 3rd numbers from the filename
        match = re.match(r"(\d+)_(\d+\.\d+)_(\d+\.\d+)\.csv", filename)
        if match:
            return float(match.group(2)), float(match.group(3))
        return None

    csv_files = list_csv_files(folder_path, randomize=randomize)
    files_dict = {}
    for file in csv_files:
        filename = os.path.basename(file)
        params = extract_params_from_filename(filename)
        if params:
            files_dict[params] = file
    return files_dict

def find_closest_csv(path, target_pid):
    files_dict = get_file_pid_dicts(path, randomize=False)

    closest_pid = None
    min_distance = float('inf')
    
    for pid in files_dict.keys():
        distance = math.sqrt((pid[0] - target_pid[0]) ** 2 + (pid[1] - target_pid[1]) ** 2)
        if distance < min_distance:
            min_distance = distance
            closest_pid = pid
    
    if closest_pid is None:
        closest_pid = (1.0, 0.3)

    return {closest_pid: files_dict[closest_pid]} if closest_pid else {}

