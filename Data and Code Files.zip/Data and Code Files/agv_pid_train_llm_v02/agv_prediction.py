########################################################################################
# Title: AGV PID Prediction using Regression models.
# Version: 1.0
# Date: 2025-03-19
# Description: This script is used to predict PID values for AGV using regression models.
########################################################################################
import os
import numpy as np

from agv_regressions import pid_regression
from agv_dataprocess import agv_analysis_csv, agv_make_train_data, print_csv_format, list_csv_files, find_closest_csv
# where our “master” ensemble lives, and the prefix for new files
BASE_ENSEMBLE = "ensemble_model.joblib"
FINETUNE_PREFIX = "ensemble_model"

def find_min_value_index(y_train):
    min_value = min(y_train)
    min_index = y_train.index(min_value)
    return min_index

def unique_candidiate(cand_list, chk_list):
    ret_list = []
    for i in range(len(cand_list)):
        if cand_list[i][:2] not in ret_list and cand_list[i][:2] not in chk_list: 
            ret_list.append(cand_list[i])
 
    return ret_list

def predict_pid(csv_files,
                split=1,
                debug=False,
                load_path=BASE_ENSEMBLE,
                use_finetune=True,
                save_prefix=FINETUNE_PREFIX,
                save_path=None):
    results = []
    for file in csv_files:
        results += agv_analysis_csv(file, split=split)

    candidate_list = []
    x_train, y_train = agv_make_train_data("RMSE_SV_PV", results)

    # Data Augmentation using LLM.

    _, rmse_candidate_list = pid_regression(
            x_train, y_train,
            load_path=load_path,
            use_finetune=use_finetune,
            save_path=save_path)
    
    rmse_candidate_list = unique_candidiate(rmse_candidate_list, x_train)
    candidate_list.append(rmse_candidate_list[0] if len(rmse_candidate_list) > 0 else (0, 0, 0))

    ret = candidate_list if len(candidate_list) <= 4 else candidate_list[:4]
    ret = [(pid[0], pid[1]) for pid in candidate_list]

    # return ret, candidate_list[0][:2]
    return ret, candidate_list[0]

def find_most_distant_pid(pids):
    def average_distance(point, others):
        distances = np.linalg.norm(others - point, axis=1)
        return np.mean(distances)

    max_avg_dist = -np.inf
    most_distant_point = None

    for i, pt in enumerate(pids):
        others = np.delete(pids, i, axis=0)
        avg_dist = average_distance(pt, others)
        if avg_dist > max_avg_dist:
            max_avg_dist = avg_dist
            most_distant_point = tuple(pt)

    return most_distant_point
    
if __name__ == "__main__":

    def main():

        path_5m = "./2025-03-13/05"
        path_10m = "./2025-03-13/10"
        path_15m = "./2025-03-13/15"
        path_20m = "./2025-03-13/20"
        path_25m = "./2025-03-13/25"

        path_5m_eval = "./2025-03-24_train1/all/05"
        path_10m_eval = "./2025-03-24_train1/all/10"
        path_15m_eval = "./2025-03-24_train1/all/15"
        path_20m_eval = "./2025-03-24_train1/all/20"
        path_25m_eval = "./2025-03-24_train1/all/25"

        base_path, eval_path = path_5m, path_5m_eval
        # base_path, eval_path = path_10m, path_10m_eval
        # base_path, eval_path = path_15m, path_15m_eval
        # base_path, eval_path = path_20m, path_20m_eval
        # base_path, eval_path = path_25m, path_25m_eval

        split = 1
        # split = 2
        # split = 4

        debug = False
        # debug = True
        print(f"(Split={split})")
        
        print(f"[{base_path}]")
        csv_files = list_csv_files(base_path)
        # base_lens = [len(csv_files), 5, 4, 3]
        # base_lens = [len(csv_files)]
        base_lens = [5]
        for base_len in base_lens:
            print(f"[Base={base_len}]")
            csv_files = csv_files[:base_len]
            
            for i in range(1):
                # print(csv_files)
                pid_list, best = predict_pid(csv_files, debug=debug)
                pid_dict = find_closest_csv(eval_path, pid_list[0])
                # pid_dict = find_closest_csv(eval_path, pid_list[1])
                pred_pids = list(pid_dict.keys())
                pred_csvs = list(pid_dict.values())
                print(pid_list, best, "-->", pred_pids[0])
                csv_files.append(pred_csvs[0])

            # pid_list, best = predict_pid(csv_files, debug=True)
            # print(csv_files[-1], pid_list, best)

    main()